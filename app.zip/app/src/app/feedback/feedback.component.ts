import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder } from '@angular/forms';
import { Feedback } from '../feedback';
import { FeedbackService } from '../feedback.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent  implements OnInit {
  feedbackForm = this.formBuilder.group({
    name: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    phone_number: new FormControl('',  [Validators.required]),
    product_name: new FormControl(''),
    performance: new FormControl(''),
    product_used: new FormControl('')
  });
  items = [];
	constructor(private formBuilder: FormBuilder, private service: FeedbackService, private router:Router) { 
    this.items = this.getProduct_used();
  }

	ngOnInit() {

	}

  getProduct_used(){
    var data=[];
    for(var i=0;i<100;i++){
      data.push({id: i+1, name: i+1});
    }
    return data;
  }
	onSubmit() {
		if (this.feedbackForm.valid) {
      const formData: Feedback = this.feedbackForm.value;
      console.log(formData);
      this.service.sendData(formData);
      this.router.navigate(['/preview']);
			// form.append('email', _v.email);
			// form.append('phone_number', _v.phone_number);
			// form.append('purpose', _v.purpose);
			// form.append('message', _v.message);
      // Submit your form to app call
		}
	}

}
