export interface Feedback {
    name: string;
    email: string;
    phone_number: string;
    product_name: string;
    performance: string;
    product_used: string;
}
