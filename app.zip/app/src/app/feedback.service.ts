import { Injectable } from '@angular/core';
import { Feedback } from './feedback';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  private formData: Feedback;
  constructor(private http: HttpClient) { 

  }

  sendData(data: Feedback){
    this.formData = data;
    // return this.http.post(environment.service.feedback.save.url,data);
  }

  getPreviewData(){
    return this.formData;
    // return this.http.get(environment.service.feedback.preview.url);
  }
}
